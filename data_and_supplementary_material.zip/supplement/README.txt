File to recreate the analysis:
paleo3_tietje_geo_range_climate_analysis.Rmd

File to recreate the supplement:
paleo3_tietje_geo_range_climate_SOM.Rmd

Workspace created by the analysis Markdown file, mandatory to run the supplement file:
workspace_analysis.RData


